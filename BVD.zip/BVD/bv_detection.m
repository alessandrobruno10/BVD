%this code allows for the detection of blood vessels from
%immunohistochemistry images

%syntax: the function gets an RGB image as input and the filename to print
%out the results of the algorithm for the detection of blood vessels from
%the images

function STATS = bv_detection_mio_immfluor3_arrow(im, filename)
warning off
%close all

im = im2double(im);
[m,n,c]=size(im);  

th_min=100*((m*n)/(696*520)); % bottom threshold value for Blood Vessel Area
th_max=75000*((m*n)/(696*520)); % upper threshold value for Blood Vessel Area

thRG=0.2;
thChannel=0.1; %filtering threshold for the red channel 
thTest=0.4; %percentuale di pixel rossi attorno alla zona bianca - valore buono 0.3
%thTest2=0.4; soglia sul valore di solidit�, non usato
ball_size=3; % parameter value used to compute the circular sector around white pixels

hough_range=[7 100];
scale_factor = m / 1040;
% The area of each pixel of full size images adds up to 0.488um x 0.488um (0.238 um^2)
linear_pixel_size = 0.488;
area_pixel_size = linear_pixel_size^2;


%all three channels are extracted from the image: Red (R), Green (G), B
%(Blue)
R=im(:,:,1);
G=im(:,:,2);
B=im(:,:,3);

%conversion from RGB space model to YCbCr
YCbCr=rgb2ycbcr(im);
Y=YCbCr(:,:,1);
Cb=YCbCr(:,:,2);
Cr=YCbCr(:,:,3);

channel = R;
%channel = G;

figure(1), imshow(im, [], 'Border', 'tight'); % OUTPUT PAPER


% PREPROCESSING
% Image average filtering with 3x3 sized mask
h = fspecial('average', 3);
channel = imfilter(channel, h);
thresh = graythresh(channel);
channel_bin = im2bw(channel, thresh);
mask_out = zeros(m, n);
mask = 1 - channel_bin;
CC = bwconncomp(mask);
pixel_list=CC.PixelIdxList;

mask2=zeros(m,n);
for i=1:length(pixel_list)
    cci=(pixel_list{i});
    li=length(cci);
    if (li>th_min)&&(li<th_max)
        mask2(cci)=1;
    end
end
%NOOUT%figure(6),imshow(mask2,[]);
CC=bwconncomp(mask2);
pixel_list=CC.PixelIdxList;
%filtered_pixel_list={};
maski=zeros(m,n);
l=length(pixel_list);
for i=1:l
    maski=zeros(m,n);
    cci=(pixel_list{i});    
    maski(cci)=1;
    maski=logical(maski);
    se = strel('ball',ball_size,0);
    maski2=imdilate(maski,se);
%     figure(8),imshow(maski2,[]);
    maski3 = maski2-maski;
%     figure(7),subplot(1,2,1),imshow(maski,[]);
%     subplot(1,2,2),imshow(maski3,[]);
    channeli=channel(maski3==1);
    test=sum(channeli>thChannel)/length(channeli)>thTest;
    %test=sum(Ri>thR)/length(Ri)<thTest;
    if ~test
        mask2(cci)=0;
    else
        STATS(i)=regionprops(maski3,'BoundingBox','Centroid','Solidity','PixelList');
    end     
end
mask_out = mask2;

[centers, radii, metric] = imfindcircles(channel_bin,hough_range);

method2_mask = zeros(m, n);

l = size(centers, 1);
for i=1:l
    cx=centers(i, 1);cy=centers(i, 2);ix=n;iy=m;r=radii(i);
    [x,y]=meshgrid(-(cx-1):(ix-cx),-(cy-1):(iy-cy));
    c_mask=((x.^2+y.^2)<=r^2);
    
    % A check on the lumen percentage of pixels is needed
    if lumen_percentage(c_mask .* channel_bin) > 0.125
        method2_mask = method2_mask + c_mask;
    end
end

mask_out = mask_out + method2_mask;
[holes_bw, mask_filled] = holes_detector(channel_bin);
mask_work = imcomplement(mask_filled);
CC=bwconncomp(holes_bw);
%Geometric features and properties are extracted from CC 
STATS=regionprops(CC,'BoundingBox','Centroid','Solidity','PixelList','PixelIdxList');
l = length(STATS);

a = zeros(l, 1);
b = zeros(l, 1);
for i=1:l
    a(i) = STATS(i).PixelList(1, 1);
    b(i) = STATS(i).PixelList(1, 2);
end
mask_work = bwfill(mask_work, a, b);
mask_out = mask_out + mask_work - imcomplement(mask_filled);
figure(101); imshow(holes_bw);
figure(102); imshow(mask_filled);


mask_out_dil = bwdist(mask_out) <= 5; 
% computes the Euclidean distance transform of the binary image mask_out. For each pixel in BW,
%the distance transform assigns a number that is the distance between that pixel and the nearest nonzero pixel of mask_out. 


L2 = labelmatrix(bwconncomp(mask_out_dil));
L2(~mask_out) = 0;
figure(103); imshow(label2rgb(L2, 'jet', [.7 .7 .7], 'shuffle'));
STATS = regionprops(L2, 'Area', 'Orientation', 'MajorAxisLength', 'MinorAxisLength', 'Eccentricity', 'Centroid', 'EquivDiameter', 'PixelIdxList', 'PixelList', 'Perimeter', 'Image');

l = length(STATS);
i = 1;
while i <= l
    if false%(STATS(i).Area < th_min) || (STATS(i).Area > th_max) || desc < 0.75
        STATS(i) = [];
        l = l-1;
    else
        i = i+1;
    end
end


figure(104); imshow(min(mask_out, 1) .* channel);


%Ellipses corresponding to blood vessels are plotted 
figure(1)
hold on
phi = linspace(0,2*pi,m*n);
cosphi = cos(phi);
sinphi = sin(phi);
for k = 1:length(STATS) 
    xbar = STATS(k).Centroid(1);
    ybar = STATS(k).Centroid(2);

    a = STATS(k).MajorAxisLength/2;
    b = STATS(k).MinorAxisLength/2;
    
    theta = pi*STATS(k).Orientation/180;
    R = [ cos(theta)   sin(theta)
         -sin(theta)   cos(theta)];

    xy = [a*cosphi; b*sinphi];
    xy = R*xy;

    x = xy(1,:) + xbar;
    y = xy(2,:) + ybar;
 
    drawArrow(x, y, [m n]);


end
hold off
%The results of the detection step is printed out in a pdf file called
%test.pdf
print(gcf, '-dpdf', 'test.pdf');

