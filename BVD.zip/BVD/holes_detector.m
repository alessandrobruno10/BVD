%this function detects holes from an image, which is given as input
%parameter to the function 
function [holes_bw, MASK_FILLED] = holes_detector(im)

if ~islogical(im)
    level = graythresh(im);
    BW = im2bw(im, level);
else
    BW = im;
end

MASK = bwmorph(BW, 'close');
MASK_FILLED = imfill(MASK, 'holes');
holes_bw = MASK_FILLED - MASK;