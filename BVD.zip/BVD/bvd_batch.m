
[file,path] = uigetfile({'*.*'},'Multiselect','on');

num_file = length(file);
TEMP=0
CHOICE = input('\n\n Press 1 or 2 to run BVD using Green or Red spectrum Blood Vessel Detection')
for i=1:num_file
    STATS = bv_detection(strcat(path,file{i}),CHOICE);
    TEMP = TEMP+length(STATS);
end
fprintf('\n The Total Number of Blood Vessels found in your images is: %d',TEMP)