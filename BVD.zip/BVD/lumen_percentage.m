%providing that a binary image is given as input to the function,
%this algorithm returns the lumen percentage as a scalar number
function percentage = lumen_percentage(im_bw)

[rows, cols]= size(im_bw);

im_convhull = bwconvhull(im_bw, 'union');
STATS = regionprops(im_convhull, 'Centroid', 'EquivDiameter');
im_0 = true(rows, cols) - im_bw;

radius = STATS(1).EquivDiameter / 4;
[columnsInImage rowsInImage] = meshgrid(1:cols, 1:rows);
circlePixels = (rowsInImage - STATS(1).Centroid(2)).^2 ...
    + (columnsInImage - STATS(1).Centroid(1)).^2 <= radius.^2;

im_lumen = im_0 & circlePixels;

percentage = sum(im_lumen(:)) / sum(circlePixels(:));