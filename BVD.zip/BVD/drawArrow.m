%this function allows to draw arrows to highlight the locations of each
%blood vessel, x and y coordinates of each bloodvessel centroid and the
%image size are given as inputs

function drawArrow(x, y, imageSize)

arrow_x_length_norm = 0.05;
arrow_y_length_norm = 0.05;
arrow_lineWidth = 2;
arrow_color = 'white';

x = round(x);
y = round(y);

if mod(length(x),2)==0
    x = [x 0];
    y = [y 0];
end

x_arr_dest = median(x);
temp = find(x == x_arr_dest);
y_arr_dest = max(y(temp));

if y_arr_dest < (1-arrow_y_length_norm)*imageSize(1)
    x_arr_dest_norm = (x_arr_dest - 1) / (imageSize(2) - 1);
    y_arr_dest_norm = 1 - ((y_arr_dest - 1) / (imageSize(1) - 1));

    x_arr_src_norm = x_arr_dest_norm;
    y_arr_src_norm = max(0, y_arr_dest_norm - arrow_y_length_norm);
else
   
    y_arr_dest = min(y(temp));

    if y_arr_dest > arrow_y_length_norm*imageSize(1)
        x_arr_dest_norm = (x_arr_dest - 1) / (imageSize(2) - 1);
        y_arr_dest_norm = 1 - ((y_arr_dest - 1) / (imageSize(1) - 1));

        x_arr_src_norm = x_arr_dest_norm;
        y_arr_src_norm = min(1, y_arr_dest_norm + arrow_y_length_norm);
    else
        y_arr_dest = median(y);
        temp = find(y == y_arr_dest);
        x_arr_dest = max(x(temp));

        if x_arr_dest < (1-arrow_x_length_norm)*imageSize(2)

            x_arr_dest_norm = (x_arr_dest - 1) / (imageSize(2) - 1);
            y_arr_dest_norm = 1 - ((y_arr_dest - 1) / (imageSize(1) - 1));

            x_arr_src_norm = min(1, x_arr_dest_norm + arrow_x_length_norm);
            y_arr_src_norm = y_arr_dest_norm;

        else
            x_arr_dest = min(x(temp));
            
            if x_arr_dest > arrow_x_length_norm*imageSize(2)
                x_arr_dest_norm = (x_arr_dest - 1) / (imageSize(2) - 1);
                y_arr_dest_norm = 1 - ((y_arr_dest - 1) / (imageSize(1) - 1));

                x_arr_src_norm = max(0, x_arr_dest_norm - arrow_x_length_norm);
                y_arr_src_norm = y_arr_dest_norm;
            else
                warning('Giving up on arrow drawing')
            end
        end
    end
end

if exist('x_arr_src_norm', 'var')
    a = annotation('arrow', [x_arr_src_norm x_arr_dest_norm], [y_arr_src_norm y_arr_dest_norm]);
    a.LineWidth = arrow_lineWidth;
    a.Color = arrow_color;
end